# Aplicativos cadastro de clientes.
_Aplicativos cadastro de cliente desenvolvido na **linguagem de programação JAVA** + banco de dados **SQLite** + **XML** utilizando a **IDE Android Studio**. Neste projeto você encontra um **CRUD completo**_.
#### _Principais funções_:
- [x] _Cadastro_.
- [x] _Listar_.
- [x] _Alterar_.
- [x] _Excluir_.
---
![device-2021-02-26-140136](https://user-images.githubusercontent.com/72363971/109333740-96e7a100-783e-11eb-8172-4772110f7041.png).

#### _Gostou do projeto, contribua com uma estrela!! é de graça e ajuda muito_.

Desde já agradeço....

atenciosamente,

gilber
